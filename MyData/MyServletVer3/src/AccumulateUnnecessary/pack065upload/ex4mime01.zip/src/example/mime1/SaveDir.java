/*
 *  SaveDir
 *
 * Created: Sat Mar  9 19:53:29 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;
import javax.servlet.http.*;

/**
 * @author Jun Inamori
 */
public class SaveDir implements HttpSessionBindingListener{

    private static final String LS=System.getProperty("line.separator");
    private static final FilesOnly FILTER=new FilesOnly();

    private String sub=null;
    private File dir=null;
    private boolean login=false;

    public SaveDir(String root,String sub){
	this.sub=sub;
	dir=new File(root,sub);
    }

    public String getSubDir(){
	return sub;
    }

    public int getNumOfFile(){
	return (dir.listFiles(FILTER)).length;
    }

    public String getFileList(){
	File[] files=dir.listFiles(FILTER);
	if(files.length==0){
	    return "<ul><li>Empty directory!</li></ul>";
	}
	String name;
	String list="<ul>"+LS;
	for(int i=0; i<files.length; i++){
	    name=files[i].getName();
	    list+="<li><a href=\"upfiles/"+sub+"/"+name+"\" target=\"_blank\">"+name+"</a></li>"+LS;
	}
	list+="</ul>"+LS;
	return list;
    }

    public synchronized boolean isLogin(){
	return login;
    }

    public synchronized boolean login(){
	if(login){
	    return false;
	}
	login=true;
	return true;
    }

    public synchronized void logout(){
	login=false;
	// Because this is just an example,
	// all the uploaded files will be deleted
	// at the time of logout.
	/*
	File[] files=dir.listFiles(FILTER);
	for(int i=0; i<files.length; i++){
	    files[i].delete();
	}
	*/
    }

    public void valueBound(HttpSessionBindingEvent evt){
    }

    public void valueUnbound(HttpSessionBindingEvent evt){
	logout();
    }

} //End of : SaveDir
