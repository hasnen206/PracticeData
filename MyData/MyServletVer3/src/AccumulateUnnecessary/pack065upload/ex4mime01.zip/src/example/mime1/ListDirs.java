/*
 *  ListDirs
 *
 * Created: Sat Mar  9 18:55:02 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.bentofw.mime.*;

/**
 * @author Jun Inamori
 */
public class ListDirs extends HttpServlet{

    private static final String NO_SESSION="NoSession.html";
    private static final String LIST_DIR="ListDirs.jsp";
    private static final String LIST_FILE="ListFiles.jsp";

    private static DirInfo dirInfo=null;

    public void init()
	throws ServletException{
	try{
	    String root=MimeParser.getInstance().getFileRoot();
	    dirInfo=new DirInfo(root);
	}
	catch(Exception ex){
	    ex.printStackTrace();
	    throw (new ServletException(ex));
	}
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res)
	throws ServletException,IOException{
	HttpSession session=req.getSession(true);
	// At this point, the new session should be created.
	if(!session.isNew()){
	    session.invalidate();
	    session=req.getSession(true);
	}
	// After 20 minutes, the session will be invalidated.
	session.setMaxInactiveInterval(1200);
	String options=dirInfo.getDirOptions();
	req.setAttribute("options",options);
	(req.getRequestDispatcher(LIST_DIR)).forward(req,res);
	return;
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res)
	throws ServletException,IOException{
	HttpSession session=req.getSession(true);
	if(session.isNew()){
	    (req.getRequestDispatcher(NO_SESSION)).forward(req,res);
	    return;
	}
	session.removeAttribute("saveDir");
	String dir=req.getParameter("dir");
	SaveDir saveDir=dirInfo.getSaveDir(dir);
	if(!(saveDir.login())){
	    String options=dirInfo.getDirOptions();
	    req.setAttribute("options",options);
	    String error="Somebody else has selected "+dir+" just before you select it. Please select another directory.";
	    req.setAttribute("error",error);
	    (req.getRequestDispatcher(LIST_DIR)).forward(req,res);
	    return;
	}
	session.setAttribute("saveDir",saveDir);
	String file_list=saveDir.getFileList();
	req.setAttribute("file_list",file_list);
	String subdir=saveDir.getSubDir();
	req.setAttribute("subdir",subdir);
	(req.getRequestDispatcher(LIST_FILE)).forward(req,res);
	return;
    }

} //End of : ListDirs
