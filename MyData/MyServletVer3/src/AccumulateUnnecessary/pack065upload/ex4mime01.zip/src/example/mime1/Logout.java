/*
 *  Logout
 *
 * Created: Sun Mar 10 01:46:44 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Jun Inamori
 */
public class Logout extends HttpServlet{

    private static final String NO_SESSION="NoSession.html";
    private static final String INDEX="index.html";

    public void doGet(HttpServletRequest req, HttpServletResponse res)
	throws ServletException,IOException{
	HttpSession session=req.getSession(true);
	if(session.isNew()){
	    (req.getRequestDispatcher(NO_SESSION)).forward(req,res);
	    return;
	}
	Object obj=session.getAttribute("saveDir");
	if(obj==null){
	    (req.getRequestDispatcher(NO_SESSION)).forward(req,res);
	    return;
	}
	SaveDir saveDir=(SaveDir)obj;
	saveDir.logout();
	(req.getRequestDispatcher(INDEX)).forward(req,res);
	return;
    }

} //End of : Logout
