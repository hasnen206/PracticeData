/*
 *  DirInfo
 *
 * Created: Sat Mar  9 20:28:50 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;
import java.util.*;

/**
 * @author Jun Inamori
 */
public class DirInfo{

    private static final String LS=System.getProperty("line.separator");
    private static final DirsOnly FILTER=new DirsOnly();
    private static final SortedMap map=new TreeMap();

    public DirInfo(String root){
	File dir=new File(root);
	File[] dirs=dir.listFiles(FILTER);
	String name;
	for(int i=0; i<dirs.length; i++){
	    name=dirs[i].getName();
	    map.put(name,(new SaveDir(root,name)));
	}
    }

    public String getDirOptions(){
	String select="";
	boolean found=false;
	Set set=map.keySet();
	Iterator it=set.iterator();
	String dir;
	SaveDir save;
	while(it.hasNext()){
	    dir=(String)(it.next());
	    save=(SaveDir)(map.get(dir));
	    if(!(save.isLogin())){
		if(found){
		    select+="<option>"+dir+LS;
		}
		else{
		    select+="<option selected>"+dir+LS;
		}
		found=true;
	    }
	}
	return select;
    }

    public SaveDir getSaveDir(String dir){
	Object obj=map.get(dir);
	if(obj==null){
	    return null;
	}
	return (SaveDir)obj;
    }

} //End of : DirInfo
