/*
 *  Upload
 *
 * Created: Sat Mar  9 19:34:02 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.bentofw.mime.*;
import com.bentofw.util.*;

/**
 * @author Jun Inamori
 */
public class Upload extends HttpServlet{

    private static final String NO_SESSION="NoSession.html";
    private static final String LIST_FILE="ListFiles.jsp";

    private static MimeParser mime=null;
    private static Set accept_type=null;

    public void init()
	throws ServletException{
	try{
	    mime=MimeParser.getInstance();
	    // Read the accepatble mime-types from
	    // WEB-INF/classes/AcceptMime.properties
	    accept_type=AcceptMime.getAcceptMime();
	}
	catch(Exception ex){
	    ex.printStackTrace();
	    throw (new ServletException(ex));
	}
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res)
	throws ServletException,IOException{
	HttpSession session=req.getSession(true);
	if(session.isNew()){
	    (req.getRequestDispatcher(NO_SESSION)).forward(req,res);
	    return;
	}
	Object obj=session.getAttribute("saveDir");
	if(obj==null){
	    (req.getRequestDispatcher(NO_SESSION)).forward(req,res);
	    return;
	}
	SaveDir saveDir=(SaveDir)obj;
	String dir=saveDir.getSubDir();
	try{
	    // The maximum file size is specified by
	    // WEB-INF/classes/MimeParser.properties ...
	    mime.parseAndSave(req,dir,accept_type);
	}
	// If the Content-Length of the request exceeds
	// the specified value...
	catch(TooLargeBodyException ex){
	    String exception=ex.getMessage();
	    req.setAttribute("exception",exception);
	}
	// If the file size exceeds the specified value...
	catch(TooLargeFileException ex){
	    String exception=ex.getMessage();
	    req.setAttribute("exception",exception);
	}
	// If the mime-type is not listed in
	// WEB-INF/classes/AcceptMime.properties ...
	catch(InvalidContentTypeException ex){
	    String exception=ex.getMessage();
	    req.setAttribute("exception",exception);
	}
	// If width or height of the file size exceeds the specified value...
	catch(LargeImageException ex){
	    String exception=ex.getMessage();
	    req.setAttribute("exception",exception);
	}
	catch(Exception ex){
	    throw (new ServletException(ex));
	}
	String file_list=saveDir.getFileList();
	req.setAttribute("file_list",file_list);
	String subdir=saveDir.getSubDir();
	req.setAttribute("subdir",subdir);
	(req.getRequestDispatcher(LIST_FILE)).forward(req,res);
	return;
    }

} //End of : Upload
