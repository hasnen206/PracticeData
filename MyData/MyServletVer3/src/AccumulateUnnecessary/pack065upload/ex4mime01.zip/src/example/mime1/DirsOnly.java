/*
 *  DirsOnly
 *
 * Created: Sat Mar  9 20:24:58 2002
 * $Revision$
 * Modified: $Date$
 *
 * Author: Jun Inamori
 * E-mail: jun@oop-research.com
 *
 * Copyright (c) 1998-2001 Jun Inamori
 * 2-24-7 Shinsenri-Kitamachi, Toyonaka ,
 * Osaka 560-0081 , Japan.
 * All rights reserved.
 *
 */
package example.mime1;

import java.io.*;

/**
 * @author Jun Inamori
 */
public class DirsOnly implements FileFilter{

    public DirsOnly(){
    }

    public boolean accept(File file){
	return file.isDirectory();
    }

} //End of : DirsOnly
